HOW TO AUTO BUILD APK USING GITHUB

1. Create GitHub Repo
2. Upload this ZIP contents
3. Push to main branch
4. Go to GitHub → Actions tab
5. Wait 2-5 minutes
6. Download APK from Artifacts

No Android Studio needed.